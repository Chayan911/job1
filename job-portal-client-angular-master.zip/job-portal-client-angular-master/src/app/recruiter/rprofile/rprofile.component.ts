import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rprofile',
  templateUrl: './rprofile.component.html',
  styleUrls: ['./rprofile.component.css']
})
export class RprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
